# Mood Tracker — Gradient Background Edition

Dynamic gradient background changes based on your last mood.
