import { useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { motion } from 'framer-motion';
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const EMOJIS = ['😀','😅','😊','😎','😢','😡','😴','🤔','🥳','❤️'];
const COLORS = ['#6366f1','#06b6d4','#f59e0b','#10b981','#ef4444','#8b5cf6','#f97316','#22c55e','#3b82f6','#a3a3a3'];

const MOOD_COLORS = {
  '😀': 'bg-gradient-to-r from-yellow-200 via-yellow-300 to-yellow-400',
  '😅': 'bg-gradient-to-r from-orange-200 via-orange-300 to-orange-400',
  '😊': 'bg-gradient-to-r from-pink-200 via-pink-300 to-pink-400',
  '😎': 'bg-gradient-to-r from-blue-200 via-sky-300 to-blue-400',
  '😢': 'bg-gradient-to-r from-blue-300 via-indigo-300 to-blue-400',
  '😡': 'bg-gradient-to-r from-red-300 via-rose-400 to-red-500',
  '😴': 'bg-gradient-to-r from-purple-200 via-purple-300 to-indigo-400',
  '🤔': 'bg-gradient-to-r from-gray-200 via-gray-300 to-gray-400',
  '🥳': 'bg-gradient-to-r from-green-200 via-emerald-300 to-lime-400',
  '❤️': 'bg-gradient-to-r from-rose-200 via-pink-300 to-red-400',
};

export default function Home(){
  const [user,setUser]=useState(null);
  const [note,setNote]=useState('');
  const [moods,setMoods]=useState([]);
  const [stats,setStats]=useState({});
  const [weekStats,setWeekStats]=useState([]);
  const [loading,setLoading]=useState(false);
  const [bgMood,setBgMood]=useState(null);

  useEffect(()=>{
    supabase.auth.getSession().then(({data:{session}})=> setUser(session?.user||null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e,session)=> setUser(session?.user||null));
    loadData();
    return ()=>sub?.subscription?.unsubscribe?.();
  },[]);

  async function signIn(){
    const email=prompt('Enter your email to sign in');
    if(!email) return;
    const { error } = await supabase.auth.signInWithOtp({ email });
    if(error) alert(error.message); else alert('Check your email for a login link');
  }
  async function signOut(){ await supabase.auth.signOut(); }

  async function ensureUser(){
    const { data:{session} } = await supabase.auth.getSession();
    const mail = session?.user?.email;
    if(!mail) return null;
    let { data: me } = await supabase.from('users').select('*').eq('email', mail).single();
    if(!me){
      const handle = 'User'+Math.floor(1000+Math.random()*9000);
      let { data: created } = await supabase.from('users').insert({ email: mail, handle }).select().single();
      me = created;
    }
    return me;
  }

  async function logMood(emoji){
    if(!user){ alert('Sign in first'); return; }
    setLoading(true);
    const me = await ensureUser();
    const { error } = await supabase.from('moods').insert({ user_id: me.id, emoji, note });
    if(error) alert(error.message);
    setNote('');
    await loadData();
    setLoading(false);
  }

  async function loadData(){
    const today = new Date(); today.setHours(0,0,0,0);
    const { data } = await supabase.from('moods').select('*').gte('created_at', today.toISOString()).order('created_at',{ascending:false});
    setMoods(data||[]);

    const counts={};
    (data||[]).forEach(m=> counts[m.emoji]=(counts[m.emoji]||0)+1 );
    setStats(counts);

    if(data && user){
      const myMood = data.find(m => m.user_id === user.id);
      if(myMood) setBgMood(myMood.emoji);
    }

    const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate()-6);
    const { data: weekData } = await supabase.from('moods').select('*').gte('created_at', weekAgo.toISOString());
    const byDay = {};
    for(const m of (weekData||[])){
      const d = new Date(m.created_at);
      const key = [d.getFullYear(), d.getMonth()+1, d.getDate()].join('-');
      byDay[key] = (byDay[key]||0)+1;
    }
    const seq = [];
    for(let i=6;i>=0;i--){
      const d = new Date(); d.setDate(d.getDate()-i);
      const key = [d.getFullYear(), d.getMonth()+1, d.getDate()].join('-');
      const label = d.toLocaleDateString(undefined,{ weekday:'short' });
      seq.push({ date: label, count: byDay[key]||0 });
    }
    setWeekStats(seq);
  }

  const pieData = useMemo(()=> Object.entries(stats).map(([emoji,value])=>({ name: emoji, value })), [stats]);

  return (
    <div className={`min-h-screen transition-colors duration-700 ${MOOD_COLORS[bgMood]||'bg-slate-50'}`}>
      <div className="nav">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="font-semibold text-lg">MoodBoard <span className="align-middle">😊</span></div>
          {user ? (
            <button className="btn btn-ghost" onClick={signOut}>Sign out</button>
          ) : (
            <button className="btn btn-primary" onClick={signIn}>Sign in</button>
          )}
        </div>
      </div>
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        {/* Mood log and analytics (same as previous) */}
      </div>
    </div>
  );
}
